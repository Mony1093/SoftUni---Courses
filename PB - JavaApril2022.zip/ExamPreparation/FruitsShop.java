package ExamPreparation;

import java.util.Scanner;

public class FruitsShop {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double strawberriesPrice = Double.parseDouble(scanner.nextLine());
        double bananasQuantity = Double.parseDouble(scanner.nextLine());
        double orangesQuantity = Double.parseDouble(scanner.nextLine());
        double raspberriesQuantity = Double.parseDouble(scanner.nextLine());
        double strawberriesQuantity = Double.parseDouble(scanner.nextLine());

        double raspberriesPrice = strawberriesPrice * 0.50;
        double orangePrice = raspberriesPrice * 0.60;
        double bananasPrice = raspberriesPrice * 0.20;

        double totalPrice = (strawberriesPrice * strawberriesQuantity + bananasPrice * bananasQuantity + orangePrice *
                orangesQuantity + raspberriesPrice * raspberriesQuantity);

        System.out.printf("%.2f", totalPrice);
    }
}
