package ExamPreparation;

import java.util.Scanner;

public class AgencyProfit {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String name = scanner.nextLine();
        int adultTicket = Integer.parseInt(scanner.nextLine());
        int kidTicket = Integer.parseInt(scanner.nextLine());
        double adultPrice = Double.parseDouble(scanner.nextLine());
        double fee = Double.parseDouble(scanner.nextLine());

        double kidPrice  = adultPrice - adultPrice * 0.70;
        double allAdultPrice = adultPrice + fee;
        double allKidPrice  = kidPrice + fee;
        double totalPrice = (kidTicket * allKidPrice) + (adultTicket * allAdultPrice);
        double profit = totalPrice * 20 / 100;
        System.out.printf("The profit of your agency from %s tickets is %.2f lv.", name, profit);



    }
}
