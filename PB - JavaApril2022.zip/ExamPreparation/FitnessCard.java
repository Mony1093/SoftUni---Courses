package ExamPreparation;

import java.util.Scanner;

public class FitnessCard {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double sum = Double.parseDouble(scanner.nextLine());
        int age = Integer.parseInt(scanner.nextLine());
        String sport = scanner.nextLine();
        char ch  = 'm';

        switch (sport){
            case "Gym":

                break;
            case "Boxing":
                break;
            case "Yoga":
                break;
            case "Zumba":
                break;
            case "Dances":
                break;
            case "Pilates":
        }



    }
}
