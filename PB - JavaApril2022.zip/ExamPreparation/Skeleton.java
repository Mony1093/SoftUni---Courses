package ExamPreparation;

import java.util.Scanner;

public class Skeleton {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int minutes = Integer.parseInt(scanner.nextLine());
        int seconds = Integer.parseInt(scanner.nextLine());
        double lengthPath = Double.parseDouble(scanner.nextLine());
        int secPer100m = Integer.parseInt(scanner.nextLine());

        double timeSec = minutes * 60 + seconds;
        double decreaseTime = lengthPath / 120 * 2.5;
        double marinTime = (lengthPath / 100) * secPer100m - decreaseTime;

        if (marinTime <= timeSec){
            System.out.println("Marin Bangiev won an Olympic quota!");
            System.out.printf("His time is %.3f.", marinTime);
        }else{
            System.out.printf("No, Marin failed! He was %.3f second slower.", marinTime - timeSec);
        }
    }
}
