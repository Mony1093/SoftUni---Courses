package ExamPreparation;

import java.util.Scanner;

public class TennisEquipment {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double priceRacket = Double.parseDouble(scanner.nextLine());
        int n = Integer.parseInt(scanner.nextLine());
        int m = Integer.parseInt(scanner.nextLine());

        double totalPriceRacket = priceRacket * n;
        double pairSneakersPrice = priceRacket/ 6;
        double totalPriceSneakers = m * pairSneakersPrice;
        double otherEquipment = (totalPriceRacket + totalPriceSneakers) * 0.2;
        double totalPrice = totalPriceRacket + totalPriceSneakers + otherEquipment;

        System.out.printf("Price to be paid by Djokovic %.0f%n",Math.floor(totalPrice / 8));
        System.out.printf("Price to be paid by sponsors %.0f%n", Math.ceil(totalPrice * 7 / 8));


    }
}
