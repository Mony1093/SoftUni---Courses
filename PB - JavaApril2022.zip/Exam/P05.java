package Exam;

import java.util.Scanner;

public class P05 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int food = Integer.parseInt(scanner.nextLine());
        String input = scanner.nextLine();
        int allEatenFood = 0;
        food = food * 1000;

        while (!input.equals("Adopted")){
            int foodPerFeeding = Integer.parseInt(input);
            allEatenFood += foodPerFeeding;

            input = scanner.nextLine();
        }
        if (food >= allEatenFood){

            System.out.printf("Food is enough! Leftovers: %d grams.", food - allEatenFood);

        }else {

            System.out.printf("Food is not enough. You need %d grams more.", allEatenFood - food);
        }



        }
    }

