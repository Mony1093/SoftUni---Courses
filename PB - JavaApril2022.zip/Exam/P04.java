package Exam;

import java.util.Scanner;

public class P04 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int countCats = Integer.parseInt(scanner.nextLine());
        double total = 0;
        int group1 = 0;
        int group2 = 0;
        int group3 = 0;

        for (int i = 1; i <= countCats ; i++) {
            double eatenFood = Double.parseDouble(scanner.nextLine());
            total += eatenFood;

            if (eatenFood >= 100 ){
                group1 += eatenFood;

            }else if ()



        }

    }
}
