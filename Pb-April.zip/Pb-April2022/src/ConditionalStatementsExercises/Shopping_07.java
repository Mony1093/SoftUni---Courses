package ConditionalStatementsExercises;

import java.util.Scanner;

public class Shopping_07 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double budget = Double.parseDouble(scanner.nextLine());
        int videoCards = Integer.parseInt(scanner.nextLine());
        int Cpu= Integer.parseInt(scanner.nextLine());
        int Ram = Integer.parseInt(scanner.nextLine());

        double videoCardsPrice = videoCards * 250;
        double CpuPrice = (videoCardsPrice * 0.35) * Cpu;
        double RamPrice = (videoCardsPrice * 0.10) * Ram;
        double finalPrice = 0;

        if (videoCards > Cpu){
            finalPrice = (videoCardsPrice + CpuPrice + RamPrice) * 0.85;
        }else{
            finalPrice = videoCardsPrice + CpuPrice + RamPrice;
        }
        double diff = Math.abs(finalPrice - budget);

        if (budget >= finalPrice) {
            System.out.printf("You have %.2f leva left!", diff);

        }else{
            System.out.printf("Not enough money! You need %.2f leva more!", diff);


        }

    }
}
