package ExamPreparation;

import java.util.Scanner;

public class MountainRun {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double record = Double.parseDouble(scanner.nextLine());
        double distance = Double.parseDouble(scanner.nextLine());
        double timePerMeter = Double.parseDouble(scanner.nextLine());
        double bonus =  30;
        double needRecord = distance * timePerMeter;
        double diffTime = (distance / 50 ) * bonus;
        double georgiTime = needRecord + diffTime;
        if (record < georgiTime){
            System.out.printf("No! He was %.2f seconds slower.%n", (georgiTime - record));

        }else{
            System.out.printf("Yes! The new record is %.2f seconds.%n", Math.floor(georgiTime));

        }


    }
}
