package ExamPreparation;

import java.util.Scanner;

public class Gymnastics {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String country = scanner.nextLine();
        String instrument = scanner.nextLine();
        double rating = 0.0;

            switch(country){
                case "Russia":
                    switch (instrument) {
                        case "ribbon": {
                            double difficulty = 9.100;
                            double execution = 9.400;
                            rating = difficulty + execution;

                            break;
                        }
                        case "hoop": {
                            double difficulty = 9.300;
                            double execution = 9.800;
                            rating = difficulty + execution;

                            break;
                        }
                        case "rope": {
                            double difficulty = 9.600;
                            double execution = 9.000;
                            rating = difficulty + execution;
                            break;
                        }
                    }
                    break;

                case "Bulgaria":
                    switch (instrument) {
                        case "ribbon": {
                            double difficulty = 9.600;
                            double execution = 9.400;
                            rating = difficulty + execution;

                            break;
                        }
                        case "hoop":
                        case "rope": {
                            double difficulty = 9.550;
                            double execution = 9.750;
                            rating = difficulty + execution;

                            break;
                        }
                    }
                    break;

                case "Italy":
                    switch (instrument) {
                        case "ribbon": {
                            double difficulty = 9.200;
                            double execution = 9.500;
                            rating = difficulty + execution;
                            break;
                        }
                        case "hoop": {
                            double difficulty = 9.450;
                            double execution = 9.350;
                            rating = difficulty + execution;
                            break;
                        }
                        case "rope": {
                            double difficulty = 9.700;
                            double execution = 9.150;
                            rating = difficulty + execution;
                            break;
                        }
                    }
                    break;
        }
           double percent = 20 - rating;

           System.out.printf("The team of %s get %.3f on %s.%n", country, rating, instrument);
           System.out.printf("%.2f%%", percent / 20 * 100);

    }
}
