package ExamPreparation;

import java.util.Scanner;

public class CareOfPuppy {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int food = Integer.parseInt(scanner.nextLine());
        String command = scanner.nextLine();
        double restFood = 0;
        while (!command.equals("Adopted")){
            int eatenFood = Integer.parseInt(scanner.nextLine());
            food *= eatenFood;

            if (eatenFood < food){
                food = food - eatenFood;

            }else{
                food = eatenFood - food;
            }


            command = scanner.nextLine();
        }

    }
}
