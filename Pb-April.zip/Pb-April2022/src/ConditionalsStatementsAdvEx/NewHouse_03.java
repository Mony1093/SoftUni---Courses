package ConditionalsStatementsAdvEx;

import java.util.Scanner;

public class NewHouse_03 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String type = scanner.nextLine();
        int count = Integer.parseInt(scanner.nextLine());
        int budget = Integer.parseInt(scanner.nextLine());
        double priceRoses = 5.00;
        double priceDahlias = 3.80;
        double priceTulips = 2.80;
        double priceNarcissus = 3.00;
        double priceGladiolus = 2.50;
        double price = 0;
        if ("Roses".equals(type)) {
            price = priceRoses * count;
        } else if ("Dahlias".equals(type)) {
            price = priceDahlias * count;
        } else if ("Tulips".equals(type)) {
            price = priceTulips * count;
        } else if ("Narcissus".equals(type)) {
            price = priceNarcissus * count;
        } else if ("Gladiolus".equals(type)) {
            price = priceGladiolus * count;
        }

        if (type.equals("Roses") && count > 80) {

            price = price - price * 0.10;

        }else if (type.equals("Dahlias") && count > 90) {

            price = price - price * 0.15;

        }else if (type.equals("Tulips") && count > 80) {

            price = price - price * 0.15;

        }else if (type.equals("Narcissus") && count < 120) {

            price = price + price * 0.15;

        }else if (type.equals("Gladiolus") && count < 80) {

            price = price + price * 0.20;
        }

        if (price <= budget){
            System.out.printf("Hey, you have a great garden with %d %s and %.2f leva left.", count, type, budget - price);
        }else {
            System.out.printf("Not enough money, you need %.2f leva more.", price - budget);

        }



        }
    }

