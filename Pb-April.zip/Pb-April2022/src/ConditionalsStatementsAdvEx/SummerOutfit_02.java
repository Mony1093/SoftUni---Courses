package ConditionalsStatementsAdvEx;

import java.util.Scanner;

public class SummerOutfit_02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int degrees = Integer.parseInt(scanner.nextLine());
        String time = scanner.nextLine();
        String OutFit = " ";
        String Shoes = " ";
        if ("Morning".equals(time)) {
            if (degrees >= 10 && degrees <= 18) {
                OutFit = "Sweatshirt";
                Shoes = "Sneakers";
            } else if (degrees > 18 && degrees <= 24) {
                OutFit = "Shirt";
                Shoes = "Moccasins";
            } else if (degrees >= 25) {
                OutFit = "T-Shirt";
                Shoes = "Sandals";
            }
        } else if ("Afternoon".equals(time)) {
            if (degrees >= 10 && degrees <= 18) {
                OutFit = "Shirt";
                Shoes = "Moccasins";
            } else if (degrees > 18 && degrees <= 24) {
                OutFit = "T-Shirt";
                Shoes = "Sandals";
            } else if (degrees >= 25) {
                OutFit = "Swim Suit";
                Shoes = "Barefoot";
            }
        } else if ("Evening".equals(time)) {
            if (degrees >= 10 && degrees <= 18) {
                OutFit = "Shirt";
                Shoes = "Moccasins";
            } else if (degrees > 18 && degrees <= 24) {
                OutFit = "Shirt";
                Shoes = "Moccasins";
            } else if (degrees >= 25) {
                OutFit = "Shirt";
                Shoes = "Moccasins";
            }
        }
        System.out.printf("It's %d degrees, get your %s and %s.", degrees, OutFit, Shoes);

    }
}
