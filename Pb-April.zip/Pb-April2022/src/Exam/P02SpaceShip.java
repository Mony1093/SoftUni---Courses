package Exam;

import java.util.Scanner;

public class P02SpaceShip {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double widthShip = Double.parseDouble(scanner.nextLine());
        double lengthShip = Double.parseDouble(scanner.nextLine());
        double heightShip = Double.parseDouble(scanner.nextLine());
        double heightAstronauts = Double.parseDouble(scanner.nextLine());

        double volumeShip = widthShip * lengthShip * heightShip;
        double volumeForRoom = (heightAstronauts + 0.40) * 2 * 2;
        double astronauts = volumeShip / volumeForRoom;

        if (astronauts < 3){
            System.out.println("The spacecraft is too small.");

        }else if (astronauts > 10){
            System.out.println("The spacecraft is too big.");

        }else{
            System.out.printf("The spacecraft holds %.0f astronauts.", Math.floor(astronauts));
        }


    }
}
