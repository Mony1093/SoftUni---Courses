package Exam;

import java.util.Scanner;

public class P01MininingRig {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int VideoCardPrice = Integer.parseInt(scanner.nextLine());
        int adapterPrice = Integer.parseInt(scanner.nextLine());
        double consumeElectrical = Double.parseDouble(scanner.nextLine());
        double profitCard =  Double.parseDouble(scanner.nextLine());

        double allVideoCardPrice = VideoCardPrice * 13;
        double allAdapterPrice = adapterPrice * 13;
        double spentMoney = 1000 + allAdapterPrice + allVideoCardPrice;
        double totalProfitCard = (profitCard - consumeElectrical) * 13;
        double returnedDays = spentMoney / totalProfitCard;

        System.out.printf("%.0f%n", spentMoney);
        System.out.printf("%.0f", Math.ceil(returnedDays));
    }
}
