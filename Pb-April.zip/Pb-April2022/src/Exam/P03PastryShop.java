package Exam;

import java.util.Scanner;

public class P03PastryShop {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String kindCake = scanner.nextLine();
        int cakes = Integer.parseInt(scanner.nextLine());
        int dayBeforeChr = Integer.parseInt(scanner.nextLine());
        double price = 0;
        // "Cake", "Souffle" или "Baklava"
         switch (kindCake){
             case "Cake":
                 if (dayBeforeChr <= 15){
                     price = 28 * cakes;
                 }else{
                     price = 28.70 * cakes;
                 }
                 break;
             case "Souffle":
                 if (dayBeforeChr <= 15){
                     price = 6.66 * cakes;
                 }else{
                     price = 9.80 * cakes;
                 }
                 break;
             case "Baklava":
                 if (dayBeforeChr <= 15){
                     price = 12.60 * cakes;
                 }else{
                     price = 16.98 * cakes;
                 }
                 break;
         }






    }
}

