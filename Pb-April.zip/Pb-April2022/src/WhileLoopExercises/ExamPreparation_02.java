package WhileLoopExercises;

import java.util.Scanner;

public class ExamPreparation_02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int countPoorGrades = Integer.parseInt(scanner.nextLine());
        int count = 0;
        int countProblems = 0;
        String lastProblem = "";
        boolean win = false;
        double totalSumGrade = 0;

        while (count < countPoorGrades){
            String problemName = scanner.nextLine();
            if (problemName.equals("Enough")){
                win = true;
                break;
            }
            int currentGrade = Integer.parseInt(scanner.nextLine());
            if (currentGrade <= 4){
                count++;
            }
            totalSumGrade = totalSumGrade + currentGrade;
            countProblems++;
            lastProblem = problemName;
        }
        if (win){
            System.out.printf("Average score: %.2f%n", totalSumGrade / countProblems);
            System.out.printf("Number of problems: %d%n", countProblems);
            System.out.printf("Last problem: %s%n", lastProblem);
        }else{
            System.out.printf("You need a break, %d poor grades.", count);
        }


    }
}
