package WhileLoopLab;

import java.util.Scanner;

public class P08Graduation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String name = scanner.nextLine();
        int poorGrades = 0;
        int goodGradesCounter = 0;
        int gradeCounter = 1;
        double allGrades = 0;
        while (goodGradesCounter < 12){
            if (poorGrades == 2){
                break;
            }
            double currentGrades = Double.parseDouble(scanner.nextLine());
            if (currentGrades < 4){
                poorGrades++;
                continue;
            }
            goodGradesCounter++;
            allGrades += currentGrades;
            gradeCounter++;
        }
           if (goodGradesCounter >= 12){
               System.out.printf(" %s graduated. Average grade: %.2f", name, allGrades / goodGradesCounter);
           }else{
               System.out.printf("%s has been excluded at %d grade", name, gradeCounter);
           }


    }
}
